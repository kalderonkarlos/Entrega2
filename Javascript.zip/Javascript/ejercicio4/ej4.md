#EJERCICIO 4 Manipular visibilidad de elementos (I)

Completad el código proporcionado para que cuando se pulse sobre el enlace "Seguir leyendo" se muestre completo el contenido de texto.

Además, una vez pulsado, el texto "Seguir leyendo" debe cambiar por "Ocultar exceso de texto", y permitir volver a esconder el texto que acabamos de añadir.

Para este ejercicio no se debe usar el localStorage sinó una variable global.
