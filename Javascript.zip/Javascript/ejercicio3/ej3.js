var respuesta = confirm("Hola Mundo");

if (respuesta) {
    console.log("Has clicado OK");
} else {
    console.log("Has clicado Cancelar");
}
