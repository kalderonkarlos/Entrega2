#EJERCICIO 2: Mensajes y alertas (II)

Modificar el script del fichero ej2.html para que:

1. El mensaje que se muestra al usuario se almacene en una variable llamada mensaje y el funcionamiento del script sea el mismo.

2. El mensaje se muestre con una alerta, y no por consola; tal como se ve en la imagen. Tened en cuenta que en Safari se ve como en la imagen, pero otros navegadores cambiarán el estilo, esto no es un problema ni un error. Tened en cuenta también que, en mi caso, el mensaje muestra el botón "Tancar" ("Cerrar", en catalán) porque es el idioma por defecto de mi ordenador y de mi navegador; si tenéis vuestro entorno configurado en español o en inglés, saldrá en ese idioma, y es correcto que salga así ya que al ser una alerta del sistema no hay manera de cambiar el idioma.
